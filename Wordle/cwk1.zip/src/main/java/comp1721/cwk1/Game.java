package comp1721.cwk1;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.io.IOException;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Collections;

public class Game {
  // TODO: Implement constructor with String parameter
  private String target;
  private int gameNumber;
  private List<String> outputStorage = new LinkedList<>();
  private String accesibility;
  private List<String> historyData = new LinkedList<>();

  public Game(String filename) throws IOException {

    target = filename;
    gameNumber = (int) ChronoUnit.DAYS.between(LocalDate.of(2021, 06, 19), LocalDate.now());
    accesibility = "n";
  }

  public Game(int num, String filename) throws IOException {
    gameNumber = num;
    target = filename;
    accesibility = "n";
  }

  public Game(String flag, String filename) throws IOException {
    accesibility = flag;
    gameNumber = (int) ChronoUnit.DAYS.between(LocalDate.of(2021, 06, 19), LocalDate.now());
    target = filename;
  }
  public Game(String flag, String filename, int num) throws IOException {
    accesibility = flag;
    gameNumber = num;
    target = filename;
  }

  // TODO: Implement constructor with int and String parameters

  // TODO: Implement play() method
  public void play() throws IOException {
    int numberOfGuesses = 0;
    Scanner input = new Scanner(System.in);
    WordList myWorldList = new WordList(target);
    System.out.println("WORDLE " + gameNumber);
    boolean wordWasFound = false;
    // Goes through every letter and compares it to the Wordle Word.
    // If equal, or it exists in the word but wrong order or not inside,
    // add to outputStorage linked list for storage and output the appropriate string
    // based on if accessible mode is on or not.
    for (int round = 1; round <= 6; round++) {
      // Error checking if a valid game object is created
      int errorCode = 1;
      String userGuess = "";
      while (errorCode == 1) {
        try {
          System.out.print("Enter guess (" + round + "/6): ");
          userGuess = input.nextLine();
          new Guess(round, userGuess);
          errorCode = 0;
        } catch (GameException e) {
          Guess.readFromPlayer();
        }
      }
      Guess guessObject = new Guess(round, userGuess);

      if (accesibility.equals("-a")) {
        System.out.println(guessObject.compareWithAccessible(myWorldList.getWord(gameNumber)));
        outputStorage.add(guessObject.compareWithAccessible(myWorldList.getWord(gameNumber)));
      } else {
        System.out.println(guessObject.compareWith(myWorldList.getWord(gameNumber)));
        outputStorage.add(guessObject.compareWith(myWorldList.getWord(gameNumber)));
      }
      if (guessObject.matches(myWorldList.getWord(gameNumber))) {
        // Outputs the appropriate win text based on number of guesses
        if (round == 1) {
          System.out.println("Superb - Got it in one!");
          wordWasFound = true;
          numberOfGuesses = 1;
          break;
        } else if (round <= 5) {
          System.out.println("Well done!");
          wordWasFound = true;
          numberOfGuesses = round;
          break;
        } else if (round == 6) {
          System.out.println("That was a close call");
          wordWasFound = true;
          numberOfGuesses = 6;
          break;
        }
      }

    }
    // If the user failed to find the word, print the word.
    if (!wordWasFound) {
      System.out.println("Nope - Better luck next time!");
      System.out.println(myWorldList.getWord(gameNumber));
      numberOfGuesses = 6;
    }
    // Write the statistics of this game to history.txt
    FileWriter fw = new FileWriter("build/history.txt", true);
    BufferedWriter bw = new BufferedWriter(fw);
    bw.write(gameNumber + ",");
    if (!wordWasFound) {
      bw.write("Unsuccessful" + ",");
    } else {
      bw.write("Successful" + ",");
    }
    bw.write("" + numberOfGuesses + "\n");
    bw.close();
  }

  // TODO: Implement save() method, with a String parameter
  public void save(String filename) throws IOException{


    try (FileWriter writer = new FileWriter(filename)) {
      for (String s : outputStorage) {writer.write(s + "\n");}
    }

  }

  public void openHistoryFile(String filename) throws IOException {
    // Opens history.txt and copies its content into a linked list of class.
    try (Scanner input = new Scanner(Paths.get(filename))) {
      while (input.hasNextLine()) {
        String line = input.nextLine();
        historyData.add(line);
      }
    }
  }

  public void winsPercentage() {
    List<String> parts = splitHistory(",");
    // Calculates (Successful games)/(Total games) * 100
    double successfulCounter = 0;
    double unsuccessfulCounter = 0;
    for (String s : parts) {
      if (s.equals("Successful")) {
        successfulCounter++;
      }
      else if (s.equals("Unsuccessful")) {
        unsuccessfulCounter++;
      }
    }
    double total = successfulCounter + unsuccessfulCounter;
    double winsPercentage = (successfulCounter / total) * 100;
    System.out.printf("Win Percentage: %3.2f%%%n", winsPercentage);
  }

  public void lenthOfCurrentWinningStreak() {
    List<String> parts = splitHistory(",");
    Collections.reverse(parts);
    String longestWinningStreakStart;
    int longestWinningStreak = 0;
    if (parts.size() >= 3) {
      longestWinningStreakStart = parts.get(1);
      if (longestWinningStreakStart.equals("Successful")) {
        longestWinningStreak = 1;
      }
    } else {
      longestWinningStreakStart = "";
    }
    if (longestWinningStreak == 1) {
      for (int i = 4; i < parts.size(); i += 3) {
        if (parts.get(i).equals(longestWinningStreakStart)) {
          longestWinningStreak++;
        } else {
          break;
        }
      }
    }

    System.out.println("Length of current winning streak: " + longestWinningStreak);
  }

  public void longestWinningStreak() {
    List<String> parts = splitHistory(",");
    int longestStreak=0;
    int temporaryLongestStreak=0;
    for (String s: parts){
      if (s.equals("Successful")||s.equals("Unsuccessful")){
        if (s.equals("Successful")){
          temporaryLongestStreak ++;
        }
        else {
          if (temporaryLongestStreak>longestStreak){
            longestStreak=temporaryLongestStreak;
            temporaryLongestStreak=0;
          }
          else{
            temporaryLongestStreak=0;
          }
        }
    }
    }
    if (temporaryLongestStreak>longestStreak){
      longestStreak=temporaryLongestStreak;}
    System.out.println("Longest Winning Spree: "+longestStreak);
  }

  public void histogramOfGuessDistribution() {
    // Prints the histogram of the distribution of guess numbers in history.txt
    List<String> parts = splitHistory(",");
    int[] guessCounter = new int[6];
    for (int i=2; i<parts.size(); i+=3){
      if (parts.get(i).equals("1")){
        guessCounter[0] ++;
      }
      else if (parts.get(i).equals("2")){
        guessCounter[1] ++;
      }
      else if (parts.get(i).equals("3")){
        guessCounter[2] ++;
      }
      else if (parts.get(i).equals("4")){
        guessCounter[3] ++;
      }
      else if (parts.get(i).equals("5")){
        guessCounter[4] ++;
      }
      else if (parts.get(i).equals("6")){
        guessCounter[5] ++;
      }
    }
    System.out.println("Histogram of rolls:" );
    for (int range = 0; range < guessCounter.length; range++) {
      String label = (range + 1) + " : ";
      System.out.println(label + convertToStars(guessCounter[range]));
  }
  }

  public List<String> splitHistory(String delimeter) {
    // Splits history.txt into comma separated values
    // This works because when writing to the file, it follows the CSV convention
    List<String> parts =  new LinkedList<>();
    for (String s : historyData) {
      for (String y: s.split(delimeter)){
        parts.add(y);
      }
    }
    return parts;
  }

  private String convertToStars(int i) {
    // Converts i into i*@ string
    StringBuilder builder = new StringBuilder();
    for (int j = 0; j < i; j++) {
      builder.append('@');
    }
    return builder.toString();
  }
}