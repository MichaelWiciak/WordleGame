package comp1721.cwk1;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;
import java.util.LinkedList;

public class WordList {
    // TODO: Implement constructor with a String parameter
    private List<String> words =  new LinkedList<>();

    public WordList(String filename) throws IOException {
        // If file exists, put all its lines into Words Linked List
        try (Scanner input = new Scanner(Paths.get(filename))) {
            while (input.hasNextLine()) {
                String line = input.nextLine();
                words.add(line);
            }
        }
    }
    // TODO: Implement size() method, returning an int
    public int size() {
        return words.size();
    }
    // TODO: Implement getWord() with an int parameter, returning a String
    public String getWord(int n){
        // Returns value of words linked list at index n only if valid
        if (n < 0 || n > words.size()-1){
            throw new GameException("Invalid gameNumber");
        }

        return words.get(n);
  }
}
