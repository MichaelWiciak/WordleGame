package comp1721.cwk1;


public class Guess {
  // Use this to get player input in readFromPlayer()

  private int guessNumber;
  private String chosenWord;

  // TODO: Implement constructor with int parameter
  public Guess(int num) {
    if (num < 1 || num > 6) {
      throw new GameException("Invalid Guess Number");
    } else {
      guessNumber = num;
    }
  }

  // TODO: Implement constructor with int and String parameters
  public Guess(int num, String word) {
    if (num < 1 || num > 6) {
      throw new GameException("Invalid Guess Number");
    } else {
      guessNumber = num;
    }
    if (word.length() != 5 || !word.matches("[a-zA-Z]+")) {
      throw new GameException("Invalid word");
    }

    chosenWord = word.toUpperCase();

  }

  // TODO: Implement getGuessNumber(), returning an int
  public int getGuessNumber() {
    return guessNumber;
  }

  // TODO: Implement getChosenWord(), returning a String
  public String getChosenWord() {
    return chosenWord;
  }

  // TODO: Implement readFromPlayer()
  public static void readFromPlayer() {
    System.out.println("Invalid input. Try again.");
  }

  // TODO: Implement compareWith(), giving it a String parameter and String return type
  public String compareWith(String target) {
    StringBuilder output = new StringBuilder();
    // returns the string based on the Wordle convention
    // If letters in both words are the same at the same index, append green box with that letter
    // If letter of guess exists in target but in wrong order, append a yellow box with that letter
    // If letter of guess word is not in target, append a while box with that letter
    String targetCopy = target;
    for (int index = 0; index < chosenWord.length(); index++) {
      if (chosenWord.charAt(index) == targetCopy.charAt(index)) {
        output.append("\033[30;102m ").append(chosenWord.charAt(index)).append(" \033[0m");
        // A letter that has been used is removed from the copy of target
        targetCopy= targetCopy.replaceFirst(String.valueOf(chosenWord.charAt(index)), " ");
      } else if (targetCopy.indexOf(chosenWord.charAt(index)) != -1) {
        output.append("\033[30;103m ").append(chosenWord.charAt(index)).append(" \033[0m");
        targetCopy=targetCopy.replaceFirst(String.valueOf(chosenWord.charAt(index)), " ");
      } else {
        output.append("\033[30;107m ").append(chosenWord.charAt(index)).append(" \033[0m");
      }
    }
    return output.toString();

  }

  // TODO: Implement matches(), giving it a String parameter and boolean return type
  public boolean matches(String target) {
    return target.equals(chosenWord);
  }

  public String compareWithAccessible(String target) {
    StringBuilder output = new StringBuilder();

    String targetCopy = target;
    // Same at the other CompareWith function but rather than appending coloured boxes
    // it outputs that information using standard letters only
    for (int index = 0; index < chosenWord.length(); index++) {
      int outputIndex = index+1;
      if (chosenWord.charAt(index) == targetCopy.charAt(index)) {
        output.append("Position "+ outputIndex + " guess is correct. ");
        targetCopy= targetCopy.replaceAll(String.valueOf(chosenWord.charAt(index)), " ");
      } else if (targetCopy.indexOf(chosenWord.charAt(index)) != -1) {
        output.append("Position "+ outputIndex + " guess is correct but in the wrong place. ");
        targetCopy=targetCopy.replaceAll(String.valueOf(chosenWord.charAt(index)), " ");
      }
    }
    return output.toString();

  }
}
