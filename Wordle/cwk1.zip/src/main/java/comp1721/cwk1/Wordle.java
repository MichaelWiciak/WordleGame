// Main program for COMP1721 Coursework 1
// DO NOT CHANGE THIS!

package comp1721.cwk1;

import java.io.IOException;


public class Wordle {
  public static void main(String[] args) throws IOException {
    Game game;
    // NOTE: To run the accessible mode, use ./gradlew runAccessible

    // Distinguishes between what different arguments supplied means for the program.
    if (args.length == 2 && args[0].equals("-a")){
      // Run in accessible mode and specify the game
      game = new Game("-a", "data/words.txt", Integer.parseInt(args[1]));
    }
    else if (args.length > 0 && args[0].equals("-a")) {
      game = new Game("-a", "data/words.txt");
    } else if (args.length > 0) {
      // Player wants to just specify the game
      game = new Game(Integer.parseInt(args[0]), "data/words.txt");
    } else {
      // Play today's game
      game = new Game("data/words.txt");
    }

    game.play();
    game.save("build/lastgame.txt");
    game.openHistoryFile("build/history.txt");
    game.winsPercentage();
    game.lenthOfCurrentWinningStreak();
    game.longestWinningStreak();
    game.histogramOfGuessDistribution();
  }
}